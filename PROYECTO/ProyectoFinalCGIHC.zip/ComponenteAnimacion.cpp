#include "ComponenteAnimacion.h"
#include "Entidad.h"
#include "ComponenteFisico.h"
#include <glm.hpp>
#include <gtc/constants.hpp>
#include <gtc/quaternion.hpp>
#include <cmath>
#include <random>
#include <chrono>

// Parametros de las diferentes animaciones
namespace {
    // Isaac
    const float ISAAC_AMPLITUD_PIERNAS = 35.0f;
    const float ISAAC_AMPLITUD_BRAZOS = 25.0f;
    const float ISAAC_AMPLITUD_CABEZA = 5.0f;
    const float ISAAC_BOBBING = 0.08f;
    
    // Variables globales para los calculos de animaciones
    // Cuphead - Caminata
    const float CUPHEAD_AMPLITUD_BRAZOS = 25.0f;         // Amplitud del swing de brazos
    const float CUPHEAD_AMPLITUD_ANTEBRAZOS = 8.0f;      // Movimiento leve de antebrazos
    const float CUPHEAD_AMPLITUD_MUSLOS = 40.0f;         // Movimiento pronunciado de muslos
    const float CUPHEAD_AMPLITUD_PIES = 30.0f;           // Movimiento pronunciado de pies
    const float CUPHEAD_BOBBING = 0.06f;                 // Movimiento vertical del cuerpo
    
    // Cuphead - Salto
    const float CUPHEAD_SALTO_COMPRESION = 0.3f;         // Factor de compresi�n (escala)
    const float CUPHEAD_SALTO_ROTACION = 360.0f;         // Grados de rotaci�n del mortal
    const float CUPHEAD_SALTO_VELOCIDAD_ROTACION = 2.0f; // Velocidad de rotaci�n (grados por unidad de velocidad vertical)
    const float CUPHEAD_SALTO_FASE_COMPRESION = 0.15f;   // Duraci�n de la fase de compresi�n en segundos
    const float CUPHEAD_SALTO_ANGULO_BRAZOS = 120.0f;    // Amplitud m�xima de brazos durante el mortal
    const float CUPHEAD_SALTO_ANGULO_MUSLOS = 90.0f;     // Amplitud m�xima de muslos durante el mortal
    const float CUPHEAD_SALTO_DOBLEZ_BRAZO = 60.0f;      // Grados de doblez de brazos en compresi�n
    const float CUPHEAD_SALTO_DOBLEZ_MUSLO = 80.0f;      // Grados de doblez de muslos en compresi�n
    const float CUPHEAD_SALTO_DOBLEZ_PIE = 60.0f;        // Grados de doblez de pies en compresi�n
    const float CUPHEAD_SALTO_FACTOR_PIE_MAX = 1.5f;     // Factor multiplicador para doblez m�ximo del pie
    const float CUPHEAD_SALTO_FACTOR_PIE_MIN = 0.3f;     // Factor multiplicador para doblez m�nimo del pie
    
    // Hollow - Movimiento dentro de la boss room
    const float HOLLOW_MIN_X = 115.0f;                   // L�mite m�nimo en X
    const float HOLLOW_MAX_X = 195.0f;                   // L�mite m�ximo en X
    const float HOLLOW_MIN_Z = -150.0f;                  // L�mite m�nimo en Z
    const float HOLLOW_MAX_Z = -100.0f;                  // L�mite m�ximo en Z
    const float HOLLOW_VELOCIDAD = 2.0f / 10;                 // Velocidad de movimiento
    const float HOLLOW_VELOCIDAD_ROTACION = 90.0f / 10;      // Velocidad de rotaci�n en grados por segundo
    const float HOLLOW_MARGEN_BORDE = 2.0f;             // Margen antes de llegar al borde para cambiar direcci�n
    const float HOLLOW_AMPLITUD_ONDULACION = 15.0f;     // Amplitud de la ondulaci�n del cuerpo
    const float HOLLOW_FRECUENCIA_ONDULACION = 3.0f / 60;    // Frecuencia de la ondulaci�n
    
    // Variables globales para los calculos de animacion
    bool animacionActiva = false;
    float tiempo = 0.0f;
    float anguloBase = 0.0f;
    float anguloOpuesto = 0.0f;
    
    // Generador de n�meros aleatorios compartido por todas las animaciones
    std::mt19937 generadorAleatorioAnimaciones(std::chrono::system_clock::now().time_since_epoch().count());
    
    // Variables para Hollow
    float hollowDireccionObjetivo = 0.0f;                // Direcci�n objetivo en grados (rotaci�n Y)
    float hollowDireccionActual = 0.0f;                  // Direcci�n actual en grados
    Entidad* entidadActual = nullptr;                    // Variable por si se tienen que recorrer varois hijos
    glm::vec3 hollowPosicionActual = glm::vec3(0.0f);   // Posici�n actual de hollow
    glm::vec3 hollowDireccionAdelante = glm::vec3(0.0f, 0.0f, 1.0f); // Direcci�n hacia adelante
    glm::vec3 hollowPosicionFutura = glm::vec3(0.0f);   // Posici�n futura para verificar colisi�n con bordes
    bool hollowCercaDelBorde = false;                    // Indica si est� cerca del borde
    glm::vec3 hollowCentroRectangulo = glm::vec3(0.0f); // Centro del �rea de movimiento
    glm::vec3 hollowHaciaElCentro = glm::vec3(0.0f);    // Vector hacia el centro
    float hollowAnguloHaciaCentro = 0.0f;                // �ngulo hacia el centro en grados
    float hollowNuevaDireccion = 0.0f;                   // Nueva direcci�n aleatoria
    float hollowDiferencia = 0.0f;                       // Diferencia entre direcci�n objetivo y actual
    float hollowRotacionDelta = 0.0f;                    // Delta de rotaci�n por frame
    float hollowRotacionAplicar = 0.0f;                  // Rotaci�n a aplicar en este frame
    float hollowFase = 0.0f;                             // Fase de ondulaci�n
    float hollowAngulo = 0.0f;                           // �ngulo de ondulaci�n
    
    // Variables para ComidaPerro 
    const float COMIDA_PERRO_AMPLITUD = 0.3f;           // Amplitud del movimiento vertical
    const float COMIDA_PERRO_FRECUENCIA = 2.0f / 60;    // Frecuencia del movimiento (ciclos por frame)
    float comidaPerroTiempo = 0.0f;                      // Tiempo acumulado para la animaci�n
    
    // Variables para Puerta
    const float PUERTA_VELOCIDAD = 5.0f / 60;                 // Velocidad de movimiento de la puerta
    const float PUERTA_DISTANCIA_TOTAL = 10.0f;           // Distancia total que baja la puerta
    bool puertaBajando = true;                           // true = bajando (abriendo), false = subiendo (cerrando)
    
    // Quaternion para guardar rotaci�n pre-salto
    glm::quat rotacionPreSaltoQuat(1.0f, 0.0f, 0.0f, 0.0f);
}

ComponenteAnimacion::ComponenteAnimacion(Entidad* entidad)
    : entidad(entidad),
    banderasAnimacion(0),
    numeroAnimaciones(0) 
{
    // Inicializar arrays de tiempos y velocidades
    for (int i = 0; i < 16; i++) {
        tiemposAnimacion[i] = 0.0f;
        velocidadesAnimacion[i] = 0.1f;
    }
}

// Activa la animacion del bit especificado
void ComponenteAnimacion::activarAnimacion(int indiceAnimacion)
{
    if (indiceAnimacion >= 0 && indiceAnimacion < 16) {
        banderasAnimacion |= (1 << indiceAnimacion);
        tiemposAnimacion[indiceAnimacion] = 0.0f;  
    }
}

// Apaga la animacion del bit especificado
void ComponenteAnimacion::desactivarAnimacion(int indiceAnimacion)
{
    if (indiceAnimacion >= 0 && indiceAnimacion < 16) {
        banderasAnimacion &= ~(1 << indiceAnimacion);
    }
}

// Checa si una animacion esta activa (la animacion del bit especificado)
bool ComponenteAnimacion::estaActiva(int indiceAnimacion) const
{
    if (indiceAnimacion >= 0 && indiceAnimacion < 16) {
        return (banderasAnimacion & (1 << indiceAnimacion)) != 0;
    }
    return false;
}

// FuncionPrincipal para actualizar la animacion1
void ComponenteAnimacion::actualizarAnimacion(int indiceAnimacion, float deltaTime, float velocidadMovimiento)
{
    if (entidad == nullptr || indiceAnimacion < 0 || indiceAnimacion >= 16) {
        return;
    }
    
    // Dependiendo de entidad llamar a su funcion de animacion
    if (entidad->nombreObjeto == "isaac_cuerpo") {
        animarIsaac(indiceAnimacion, deltaTime, velocidadMovimiento);
    }
    else if (entidad->nombreObjeto == "hollow") {
        animarHollow(indiceAnimacion, deltaTime);
    }
    else if (entidad->nombreObjeto == "comida_perro") {
		animarComidaPerro(indiceAnimacion, deltaTime);
    }
    else if(entidad->nombreObjeto == "puerta_secret_room") {
        animarPuerta(indiceAnimacion, deltaTime);
	}
    else if (entidad->nombreObjeto == "cuphead_torso") {
        // �ndice 0: Animaci�n de caminata
        // �ndice 1: Animaci�n de salto
        if (indiceAnimacion == 0) {
            animarCuphead(indiceAnimacion, deltaTime, velocidadMovimiento);
        }
        else if (indiceAnimacion == 1) {
            animarCupheadSalto(indiceAnimacion, deltaTime);
        }

    }
}

// Se utiliza funcion senoidal para animar a Isaac caminando (se utiliza funcion senoidal del tiempo para saber que angulo darle a los brazos y a las piernas)
// Se termina si tiempo acumulado llega a 2 * pi
void ComponenteAnimacion::animarIsaac(int indiceAnimacion, float deltaTime, float velocidadMovimiento)
{
    bool animacionActiva = estaActiva(indiceAnimacion);
    
    // Si hay movimiento, activar animaci�n
    if (velocidadMovimiento > 0.01f) {
        if (!animacionActiva) {
            activarAnimacion(indiceAnimacion);
        }
        
        // Acumular tiempo
        tiemposAnimacion[indiceAnimacion] += deltaTime * velocidadesAnimacion[indiceAnimacion];
        
		// se ajusta para que la posicion sea la misma cuando se empezo a mover
        if (tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
            tiemposAnimacion[indiceAnimacion] -= glm::two_pi<float>();
        }
    }
    else if (animacionActiva) {
        // Continuar hasta completar el ciclo
        tiemposAnimacion[indiceAnimacion] += deltaTime * velocidadesAnimacion[indiceAnimacion];

        // Verificar si ya termino la animacion
        if (tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
            // Ajustar el tiempo para que se posicionen bien las partes del cuerpo
            tiemposAnimacion[indiceAnimacion] = glm::two_pi<float>();
        }
    }
    else {
        // No hay movimiento y no hay animaci�n activa
        return;
    }
    
    // Aplicar transformaciones de animaci�n
    tiempo = tiemposAnimacion[indiceAnimacion];
    anguloBase = sin(tiempo);
    anguloOpuesto = sin(tiempo + glm::pi<float>());

    for (auto* hijo : entidad->hijos) {
        if (hijo == nullptr) continue;
        
        const std::string& nombre = hijo->nombreObjeto;
        
        // Piernas
        if (nombre.find("pierna_derecha") != std::string::npos) {
            hijo->rotacionLocalQuat = glm::angleAxis(glm::radians(hijo->rotacionInicial.x + (anguloBase * ISAAC_AMPLITUD_PIERNAS)), glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (nombre.find("pierna_izquierda") != std::string::npos) {
            hijo->rotacionLocalQuat = glm::angleAxis(glm::radians(hijo->rotacionInicial.x + (anguloOpuesto * ISAAC_AMPLITUD_PIERNAS)), glm::vec3(1.0f, 0.0f, 0.0f));
        }
        // Brazos
        else if (nombre.find("brazo_derecho") != std::string::npos) {
            hijo->rotacionLocalQuat = glm::angleAxis(glm::radians(hijo->rotacionInicial.x + (anguloOpuesto * ISAAC_AMPLITUD_BRAZOS)), glm::vec3(1.0f, 0.0f, 0.0f));
        }
        else if (nombre.find("brazo_izquierdo") != std::string::npos) {
            hijo->rotacionLocalQuat = glm::angleAxis(glm::radians(hijo->rotacionInicial.x + (anguloBase * ISAAC_AMPLITUD_BRAZOS)), glm::vec3(1.0f, 0.0f, 0.0f));
        }
        
        // Cabeza
        else if (nombre.find("cabeza") != std::string::npos) {
            hijo->rotacionLocalQuat = glm::angleAxis(glm::radians(hijo->rotacionInicial.z + (anguloBase * ISAAC_AMPLITUD_CABEZA)), glm::vec3(0.0f, 0.0f, 1.0f));
            hijo->posicionLocal.y = hijo->posicionInicial.y + abs(sin(tiempo * 2.0f)) * ISAAC_BOBBING;
        }
        
        hijo->actualizarTransformacion();
    }
    
    // Despu�s de aplicar transformaciones, verificar si ya termino la animacion para desactivarla
    if (velocidadMovimiento <= 0.01f && tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
        desactivarAnimacion(indiceAnimacion);
        tiemposAnimacion[indiceAnimacion] = 0.0f;
    }
}

void ComponenteAnimacion::animarHollow(int indiceAnimacion, float deltaTime) {
    if (entidad == nullptr) {
        return;
    }
    
    animacionActiva = estaActiva(indiceAnimacion);
    
    // Inicializar la configuraci�n espec�fica de Hollow solo al activar la animaci�n
    if (!animacionActiva) {
        // Activar la animaci�n
        activarAnimacion(indiceAnimacion);
        
        // Extraer el �ngulo Y actual del quaternion
        glm::vec3 eulerAngles = glm::eulerAngles(entidad->rotacionLocalQuat);
        hollowDireccionActual = glm::degrees(eulerAngles.y);
        hollowDireccionObjetivo = hollowDireccionActual;
    }
    
    // Obtener posici�n actual
    hollowPosicionActual = entidad->posicionLocal;
    
    // Calcular la direcci�n hacia adelante
    hollowDireccionAdelante = entidad->rotacionLocalQuat * glm::vec3(0.0f, 0.0f, 1.0f);
    hollowDireccionAdelante.y = 0.0f; 
    if (glm::length(hollowDireccionAdelante) > 0.01f) {
        hollowDireccionAdelante = glm::normalize(hollowDireccionAdelante);
    } else {
        // Si la direcci�n es muy peque�a, usar una por defecto
        hollowDireccionAdelante = glm::vec3(0.0f, 0.0f, 1.0f);
    }
    
    // Calcular posici�n futura basada en la direcci�n actual
    hollowPosicionFutura = hollowPosicionActual + hollowDireccionAdelante * HOLLOW_VELOCIDAD * deltaTime * 2.0f;
    
    // Verificar si est� cerca del borde
    hollowCercaDelBorde = (hollowPosicionFutura.x <= HOLLOW_MIN_X + HOLLOW_MARGEN_BORDE ||
                           hollowPosicionFutura.x >= HOLLOW_MAX_X - HOLLOW_MARGEN_BORDE ||
                           hollowPosicionFutura.z <= HOLLOW_MIN_Z + HOLLOW_MARGEN_BORDE ||
                           hollowPosicionFutura.z >= HOLLOW_MAX_Z - HOLLOW_MARGEN_BORDE);
    
    // Cambiar direcci�n aleatoriamente si est� cerca del borde
    if (hollowCercaDelBorde) {
        // Calcular direcci�n hacia el centro del �rea
        hollowCentroRectangulo = glm::vec3((HOLLOW_MIN_X + HOLLOW_MAX_X) * 0.5f, 
                                            hollowPosicionActual.y, 
                                            (HOLLOW_MIN_Z + HOLLOW_MAX_Z) * 0.5f);
        hollowHaciaElCentro = glm::normalize(hollowCentroRectangulo - hollowPosicionActual);
        
        // Calcular �ngulo hacia el centro
        hollowAnguloHaciaCentro = glm::degrees(atan2(hollowHaciaElCentro.x, hollowHaciaElCentro.z));
        
        // A�adir variaci�n aleatoria de �90 grados alrededor de la direcci�n al centro
        std::uniform_real_distribution<float> distribVariacion(-90.0f, 90.0f);
        hollowNuevaDireccion = hollowAnguloHaciaCentro + distribVariacion(generadorAleatorioAnimaciones);
        
        hollowDireccionObjetivo = hollowNuevaDireccion;
    }
    
    // Rotar hacia la direcci�n objetivo
    hollowDiferencia = hollowDireccionObjetivo - hollowDireccionActual;
    
    // Ajustar a que sea entre -180 y 180
    while (hollowDiferencia > 180.0f) hollowDiferencia -= 360.0f;
    while (hollowDiferencia < -180.0f) hollowDiferencia += 360.0f;
    
    // Aplicar rotaci�n gradual
    if (abs(hollowDiferencia) > 0.1f) {
        hollowRotacionDelta = HOLLOW_VELOCIDAD_ROTACION * deltaTime;
        hollowRotacionAplicar = 0.0f;
        
        if (abs(hollowDiferencia) < hollowRotacionDelta) {
            hollowRotacionAplicar = hollowDiferencia;
            hollowDireccionActual = hollowDireccionObjetivo;
        } else {
            hollowRotacionAplicar = (hollowDiferencia > 0.0f ? hollowRotacionDelta : -hollowRotacionDelta);
            hollowDireccionActual += hollowRotacionAplicar;
        }
        
        // Ajustar a que sea entre -180 y 180
        while (hollowDireccionActual >= 360.0f) hollowDireccionActual -= 360.0f;
        while (hollowDireccionActual < 0.0f) hollowDireccionActual += 360.0f;
        
        // Aplicar la rotaci�n
        entidad->rotacionLocal.y = hollowRotacionAplicar;
    }
    
    // Mover hacia adelante en la direcci�n actual
    hollowDireccionAdelante = entidad->rotacionLocalQuat * glm::vec3(0.0f, 0.0f, 1.0f);
    hollowDireccionAdelante.y = 0.0f;
    if (glm::length(hollowDireccionAdelante) > 0.01f) {
        hollowDireccionAdelante = glm::normalize(hollowDireccionAdelante);
    } else {
        hollowDireccionAdelante = glm::vec3(0.0f, 0.0f, 1.0f);
    }
    
    entidad->posicionLocal += hollowDireccionAdelante * HOLLOW_VELOCIDAD * deltaTime;
    
    // Limitar la posici�n dentro de los l�mites
    entidad->posicionLocal.x = glm::clamp(entidad->posicionLocal.x, HOLLOW_MIN_X, HOLLOW_MAX_X);
    entidad->posicionLocal.z = glm::clamp(entidad->posicionLocal.z, HOLLOW_MIN_Z, HOLLOW_MAX_Z);
    
    // Aplicar ondulaci�n al cuerpo 
    tiempo += deltaTime * HOLLOW_FRECUENCIA_ONDULACION;
    
    // Rotar cada una de las partes de hollow
    entidadActual = entidad->hijos[0];
        
    for (int i = 0; i < 5 && entidadActual != nullptr; i++) {
        // Calcular fase de ondulaci�n para este segmento
        hollowFase = tiempo - (i * 0.3f);
        hollowAngulo = sin(hollowFase) * HOLLOW_AMPLITUD_ONDULACION;
            
        // Aplicar rotaci�n de ondulaci�n 
        entidadActual->rotacionLocalQuat = 
            glm::angleAxis(glm::radians(entidadActual->rotacionInicial.x), glm::vec3(1.0f, 0.0f, 0.0f)) *
            glm::angleAxis(glm::radians(entidadActual->rotacionInicial.y + hollowAngulo), glm::vec3(0.0f, 1.0f, 0.0f)) *
            glm::angleAxis(glm::radians(entidadActual->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f));
            
        entidadActual->rotacionLocal = glm::vec3(0.0f);
            
        // Avanzar al hijo de la entidad
        if (!entidadActual->hijos.empty()) {
            entidadActual = entidadActual->hijos[0];
        } else {
            entidadActual = nullptr;
        }
        
    }
    
    // Actualizar transformaci�n de la cabeza
    entidad->actualizarTransformacion();
}

// Animaci�n de caminata para Cuphead
void ComponenteAnimacion::animarCuphead(int indiceAnimacion, float deltaTime, float velocidadMovimiento)
{
    if (estaActiva(1)) {  // �ndice 1 = animaci�n de salto
        // Si la animaci�n de caminata estaba activa, desactivarla
        if (estaActiva(indiceAnimacion)) {
            desactivarAnimacion(indiceAnimacion);
            tiemposAnimacion[indiceAnimacion] = 0.0f;
            
            // Restaurar posici�n Y original del torso
            entidad->posicionLocal.y = entidad->posicionInicial.y;
            entidad->actualizarTransformacion();
        }
        return;  // No ejecutar animaci�n de caminata mientras se salta
    }
    
    animacionActiva = estaActiva(indiceAnimacion);
    
    // Si hay movimiento, activar animaci�n
    if (velocidadMovimiento > 0.01f) {
        if (!animacionActiva) {
            activarAnimacion(indiceAnimacion);
        }
        
        // Acumular tiempo
        tiemposAnimacion[indiceAnimacion] += deltaTime * velocidadesAnimacion[indiceAnimacion];
        
        // Se ajusta para que la posicion sea la misma cuando se empez� a mover
        if (tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
            tiemposAnimacion[indiceAnimacion] -= glm::two_pi<float>();
        }
    }
    else if (animacionActiva) {
        // Continuar hasta completar el ciclo
        tiemposAnimacion[indiceAnimacion] += deltaTime * velocidadesAnimacion[indiceAnimacion];
        
        // Verificar si ya termin� la animaci�n
        if (tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
            // Ajustar el tiempo para que se posicionen bien las partes del cuerpo
            tiemposAnimacion[indiceAnimacion] = glm::two_pi<float>();
        }
    }
    else {
        // No hay movimiento y no hay animaci�n activa
        return;
    }
    
    // Aplicar transformaciones de animaci�n
    tiempo = tiemposAnimacion[indiceAnimacion];
    anguloBase = sin(tiempo);
    anguloOpuesto = sin(tiempo + glm::pi<float>());

    // Bobbing del torso (movimiento vertical sutil)
    entidad->posicionLocal.y = entidad->posicionInicial.y + 
                               abs(sin(tiempo * 2.0f)) * CUPHEAD_BOBBING;
    
    for (auto* hijo : entidad->hijos) {
        if (hijo == nullptr) continue;
        
        const std::string& nombre = hijo->nombreObjeto;
        
        // Brazos - movimiento alternado adelante/atr�s (rotaci�n en eje X)
        if (nombre.find("cuphead_brazo_derecho") != std::string::npos) {
            hijo->rotacionLocal.x = hijo->rotacionInicial.x + (anguloBase * CUPHEAD_AMPLITUD_BRAZOS);
            
            hijo->rotacionLocalQuat = 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
            
            // Animar antebrazo derecho si existe
            for (auto* nieto : hijo->hijos) {
                if (nieto && nieto->nombreObjeto.find("cuphead_antebrazo_derecho") != std::string::npos) {
                    nieto->rotacionLocal.x = nieto->rotacionInicial.x + (anguloBase * CUPHEAD_AMPLITUD_ANTEBRAZOS * 0.5f);
                    
                    nieto->rotacionLocalQuat = 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                    nieto->actualizarTransformacion();
                }
            }
        }
        else if (nombre.find("cuphead_brazo_izquierdo") != std::string::npos) {
            hijo->rotacionLocal.x = hijo->rotacionInicial.x + (anguloOpuesto * CUPHEAD_AMPLITUD_BRAZOS);
            
            hijo->rotacionLocalQuat = 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
            
            // Animar antebrazo izquierdo si existe
            for (auto* nieto : hijo->hijos) {
                if (nieto && nieto->nombreObjeto.find("cuphead_antebrazo_izquierdo") != std::string::npos) {
                    nieto->rotacionLocal.x = nieto->rotacionInicial.x + (anguloOpuesto * CUPHEAD_AMPLITUD_ANTEBRAZOS * 0.5f);
                    
                    nieto->rotacionLocalQuat = 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                    nieto->actualizarTransformacion();
                }
            }
        }
        
        // Piernas - movimiento pronunciado adelante/atr�s (rotaci�n en eje X)
        else if (nombre.find("cuphead_muslo_derecho") != std::string::npos) {
            hijo->rotacionLocal.x = hijo->rotacionInicial.x + (anguloOpuesto * CUPHEAD_AMPLITUD_MUSLOS);
            
            hijo->rotacionLocalQuat = 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
            
            // Animar pie derecho con movimiento m�s pronunciado
            for (auto* nieto : hijo->hijos) {
                if (nieto && nieto->nombreObjeto.find("cuphead_pie_derecho") != std::string::npos) {
                    // El pie se dobla m�s cuando el muslo est� hacia atr�s
                    float factorPie = anguloOpuesto < 0 ? abs(anguloOpuesto) * CUPHEAD_SALTO_FACTOR_PIE_MAX : anguloOpuesto * CUPHEAD_SALTO_FACTOR_PIE_MIN;
                    nieto->rotacionLocal.x = nieto->rotacionInicial.x + (factorPie * CUPHEAD_AMPLITUD_PIES);
                    
                    nieto->rotacionLocalQuat = 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                    nieto->actualizarTransformacion();
                }
            }
        }
        else if (nombre.find("cuphead_muslo_izquierdo") != std::string::npos) {
            hijo->rotacionLocal.x = hijo->rotacionInicial.x + (anguloBase * CUPHEAD_AMPLITUD_MUSLOS);
            
            hijo->rotacionLocalQuat = 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
            
            // Animar pie izquierdo con movimiento m�s pronunciado
            for (auto* nieto : hijo->hijos) {
                if (nieto && nieto->nombreObjeto.find("cuphead_pie_izquierdo") != std::string::npos) {
                    // El pie se dobla m�s cuando el muslo est� hacia atr�s 
                    float factorPie = anguloBase < 0 ? abs(anguloBase) * CUPHEAD_SALTO_FACTOR_PIE_MAX : anguloBase * CUPHEAD_SALTO_FACTOR_PIE_MIN;
                    nieto->rotacionLocal.x = nieto->rotacionInicial.x + (factorPie * CUPHEAD_AMPLITUD_PIES);
                    
                    nieto->rotacionLocalQuat = 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                        glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                    nieto->actualizarTransformacion();
                }
            }
        }
        
        hijo->actualizarTransformacion();
    }
    
    
    // Despu�s de aplicar transformaciones, verificar si ya termin� la animaci�n para desactivarla
    if (velocidadMovimiento <= 0.01f && tiemposAnimacion[indiceAnimacion] >= glm::two_pi<float>()) {
        desactivarAnimacion(indiceAnimacion);
        tiemposAnimacion[indiceAnimacion] = 0.0f;
        
        // Restaurar posici�n Y original
        entidad->posicionLocal.y = entidad->posicionInicial.y;
    }
    entidad->actualizarTransformacion();

}

// Animaci�n de salto con mortal para Cuphead
void ComponenteAnimacion::animarCupheadSalto(int indiceAnimacion, float deltaTime)
{
    bool animacionActiva = estaActiva(indiceAnimacion);
    
    // Si la animaci�n no est� activa, no hacer nada
    if (!animacionActiva) {
        return;
    }
    
    // Verificar si la entidad tiene componente f�sico
    if (entidad->fisica == nullptr) {
        desactivarAnimacion(indiceAnimacion);
        return;
    }
    
    // Al inicio de la animaci�n (tiempo = 0), guardar la rotaci�n actual
    if (tiemposAnimacion[indiceAnimacion] == 0.0f) {
        rotacionPreSaltoQuat = entidad->rotacionLocalQuat;
    }
    
    // Verificar si el personaje ha aterrizado
    if (entidad->fisica->estaEnSuelo() && tiemposAnimacion[indiceAnimacion] > 0.0f) {
        // Terminar la animaci�n
        desactivarAnimacion(indiceAnimacion);
        tiemposAnimacion[indiceAnimacion] = 0.0f;
        
        // Restaurar todas las transformaciones de los hijos
        for (auto* hijo : entidad->hijos) {
            if (hijo == nullptr) continue;
            
			hijo->posicionLocal = hijo->posicionInicial;
            hijo->rotacionLocal = hijo->rotacionInicial;
            hijo->rotacionLocalQuat = hijo->rotacionInicialQuat;
            hijo->escalaLocal = hijo->escalaInicial;
            hijo->actualizarTransformacion();

            // Restaurar tambi�n los nietos (antebrazos y pies)
            for (auto* nieto : hijo->hijos) {
                if (nieto == nullptr) continue;
				nieto->posicionLocal = nieto->posicionInicial;
                nieto->rotacionLocal = nieto->rotacionInicial;
                nieto->rotacionLocalQuat = nieto->rotacionInicialQuat;
                nieto->escalaLocal = nieto->escalaInicial;
                nieto->actualizarTransformacion();
            }
        }
        
        // Restaurar a la rotaci�n antes del salto
        entidad->rotacionLocalQuat = rotacionPreSaltoQuat;
        entidad->escalaLocal = entidad->escalaInicial;
        entidad->actualizarTransformacion();
        
        return;
    }
    
    // Acumular tiempo solo si no est� en el suelo
    tiemposAnimacion[indiceAnimacion] += deltaTime;
    
    // Fase 1: Compresi�n 
    if (tiemposAnimacion[indiceAnimacion] < CUPHEAD_SALTO_FASE_COMPRESION && !entidad->fisica->estaEnSuelo()) {
        float factorCompresion = tiemposAnimacion[indiceAnimacion] / CUPHEAD_SALTO_FASE_COMPRESION; // 0.0 a 1.0
        
        // Comprimir el torso 
        float escalaY = 1.0f - (factorCompresion * CUPHEAD_SALTO_COMPRESION);
        float escalaXZ = 1.0f + (factorCompresion * CUPHEAD_SALTO_COMPRESION * 0.5f);
        
        entidad->escalaLocal = glm::vec3(
            entidad->escalaInicial.x * escalaXZ,
            entidad->escalaInicial.y * escalaY,
            entidad->escalaInicial.z * escalaXZ
        );
        
        // Comprimir extremidades hacia el cuerpo
        for (auto* hijo : entidad->hijos) {
            if (hijo == nullptr) continue;
            
            const std::string& nombre = hijo->nombreObjeto;
            
            // Brazos hacia adentro
            if (nombre.find("cuphead_brazo") != std::string::npos) {
                hijo->rotacionLocal.z = hijo->rotacionInicial.z + (factorCompresion * CUPHEAD_SALTO_DOBLEZ_BRAZO * 
                    (nombre.find("derecho") != std::string::npos ? 1.0f : -1.0f));
                
                hijo->rotacionLocalQuat = 
                    glm::angleAxis(glm::radians(hijo->rotacionLocal.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.x), glm::vec3(1.0f, 0.0f, 0.0f));
            }
            // Piernas dobladas
            else if (nombre.find("cuphead_muslo") != std::string::npos) {
                hijo->rotacionLocal.x = hijo->rotacionInicial.x - (factorCompresion * CUPHEAD_SALTO_DOBLEZ_MUSLO);
                
                hijo->rotacionLocalQuat = 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                
                // Doblar los pies m�s
                for (auto* nieto : hijo->hijos) {
                    if (nieto && nieto->nombreObjeto.find("cuphead_pie") != std::string::npos) {
                        nieto->rotacionLocal.x = nieto->rotacionInicial.x + (factorCompresion * CUPHEAD_SALTO_DOBLEZ_PIE);
                        
                        nieto->rotacionLocalQuat = 
                            glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                            glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                            glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                        nieto->actualizarTransformacion();
                    }
                }
            }
            
            hijo->actualizarTransformacion();
        }
    }
    // Fase 2: Mortal en el aire
    else {
        // Descomprimir completamente
        entidad->escalaLocal = entidad->escalaInicial;
        
        // Calcular rotaci�n basada en la velocidad vertical acumulada
        // La rotaci�n aumenta mientras el personaje est� en el aire
        float velocidadVertical = entidad->fisica->velocidad.y;
        float tiempoEnAire = tiemposAnimacion[indiceAnimacion] - CUPHEAD_SALTO_FASE_COMPRESION;
        
        // Calcular rotaci�n acumulada (m�s r�pida al inicio, m�s lenta al final)
        float rotacionActual = tiempoEnAire * CUPHEAD_SALTO_VELOCIDAD_ROTACION * abs(velocidadVertical);
        
        // Limitar la rotaci�n a un m�ximo para evitar giros excesivos
        if (rotacionActual > CUPHEAD_SALTO_ROTACION) {
            rotacionActual = CUPHEAD_SALTO_ROTACION;
        }
        
        // Aplicar rotaci�n del mortal sobre la rotaci�n pre-salto
        glm::quat rotacionMortal = glm::angleAxis(glm::radians(rotacionActual), glm::vec3(1.0f, 0.0f, 0.0f));
        entidad->rotacionLocalQuat = rotacionPreSaltoQuat * rotacionMortal;
        
        // Factor de progreso del mortal (0.0 a 1.0 basado en la rotaci�n)
        float factorMortal = rotacionActual / CUPHEAD_SALTO_ROTACION;
        
        // Extender extremidades gradualmente durante el mortal
        for (auto* hijo : entidad->hijos) {
            if (hijo == nullptr) continue;
            
            const std::string& nombre = hijo->nombreObjeto;
            
            // Brazos: primero hacia adelante, luego hacia atr�s siguiendo el mortal
            if (nombre.find("cuphead_brazo") != std::string::npos) {
                float anguloBrazo = sin(factorMortal * glm::pi<float>()) * CUPHEAD_SALTO_ANGULO_BRAZOS;
                hijo->rotacionLocal.x = hijo->rotacionInicial.x + anguloBrazo;
                hijo->rotacionLocal.z = hijo->rotacionInicial.z;
                
                hijo->rotacionLocalQuat = 
                    glm::angleAxis(glm::radians(hijo->rotacionLocal.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
            }
            // Piernas: extender durante el mortal
            else if (nombre.find("cuphead_muslo") != std::string::npos) {
                float anguloMuslo = sin(factorMortal * glm::pi<float>()) * -CUPHEAD_SALTO_ANGULO_MUSLOS;
                hijo->rotacionLocal.x = hijo->rotacionInicial.x + anguloMuslo;
                
                hijo->rotacionLocalQuat = 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                    glm::angleAxis(glm::radians(hijo->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                
                // Extender los pies
                for (auto* nieto : hijo->hijos) {
                    if (nieto && nieto->nombreObjeto.find("cuphead_pie") != std::string::npos) {
                        float anguloPie = (1.0f - factorMortal) * CUPHEAD_SALTO_DOBLEZ_PIE;
                        nieto->rotacionLocal.x = nieto->rotacionInicial.x + anguloPie;
                        
                        nieto->rotacionLocalQuat = 
                            glm::angleAxis(glm::radians(nieto->rotacionInicial.z), glm::vec3(0.0f, 0.0f, 1.0f)) * 
                            glm::angleAxis(glm::radians(nieto->rotacionInicial.y), glm::vec3(0.0f, 1.0f, 0.0f)) * 
                            glm::angleAxis(glm::radians(nieto->rotacionLocal.x), glm::vec3(1.0f, 0.0f, 0.0f));
                        nieto->actualizarTransformacion();
                    }
                }
            }
            
            hijo->actualizarTransformacion();
        }
    }
    
    // Actualizar transformaci�n del torso
    entidad->actualizarTransformacion();
}

// Animacion para el item de la secret room (sube y baja todo el tiempo)
void ComponenteAnimacion::animarComidaPerro(int indiceAnimacion, float deltaTime) {
    if (entidad == nullptr) {
        return;
    }
    
    animacionActiva = estaActiva(indiceAnimacion);
    
    // Activar la animaci�n si no est� activa
    if (!animacionActiva) {
        activarAnimacion(indiceAnimacion);
    }
    
    // Acumular tiempo para el movimiento sinusoidal
    comidaPerroTiempo += deltaTime * COMIDA_PERRO_FRECUENCIA;
    
    // Mantener el tiempo en el rango 0 y 2 * pi
    if (comidaPerroTiempo >= glm::two_pi<float>()) {
        comidaPerroTiempo -= glm::two_pi<float>();
    }

    // Aplicar el desplazamiento 
    entidad->posicionLocal.y = entidad->posicionInicial.y + sin(comidaPerroTiempo) * COMIDA_PERRO_AMPLITUD;
    
    // Actualizar transformaci�n
    entidad->actualizarTransformacion();
}

// Animacion para la puerta de la secret room (abre y cierra verticalmente)
void ComponenteAnimacion::animarPuerta(int indiceAnimacion, float deltaTime) {
    if (entidad == nullptr) {
        return;
    }
    
    animacionActiva = estaActiva(indiceAnimacion);
    
    
    // Calcular el desplazamiento hacia abajo
    if (puertaBajando) {
        // Abrir la puerta (bajar)
        entidad->posicionLocal.y -= PUERTA_VELOCIDAD * deltaTime;
        
        // Verificar si ya se termino la animacion
        if (entidad->posicionLocal.y <= entidad->posicionInicial.y - PUERTA_DISTANCIA_TOTAL) {
            entidad->posicionLocal.y = entidad->posicionInicial.y - PUERTA_DISTANCIA_TOTAL;
            puertaBajando = false;  // Cambiar direcci�n para la pr�xima activaci�n
            desactivarAnimacion(indiceAnimacion);  // Terminar animaci�n
        }
    } else {
        // Cerrar la puerta *subir)
        entidad->posicionLocal.y += PUERTA_VELOCIDAD * deltaTime;
        
        // Verificar si lleg� a la posici�n inicial
        if (entidad->posicionLocal.y >= entidad->posicionInicial.y) {
            entidad->posicionLocal.y = entidad->posicionInicial.y;
            puertaBajando = true;                // Cambiar direccino
            desactivarAnimacion(indiceAnimacion);  // Se termina la animacion
        }
    }
    
    // Actualizar transformaci�n
    entidad->actualizarTransformacion();
}

void ComponenteAnimacion::cargarKeyframes(void)
{
    std::ifstream file(std::string("keyframes_" + entidad->nombreObjeto + ".txt"));

    while (file >> KeyFrame[FrameIndex].movX
        >> KeyFrame[FrameIndex].movY
        >> KeyFrame[FrameIndex].movZ
        >> KeyFrame[FrameIndex].giroX
        >> KeyFrame[FrameIndex].giroY
        >> KeyFrame[FrameIndex].giroZ)
    {
        FrameIndex++;
    }

    file.close();
}

void ComponenteAnimacion::interpolation(void)
{
    KeyFrame[playIndex].movXInc = (KeyFrame[playIndex + 1].movX - KeyFrame[playIndex].movX) / i_max_steps;
    KeyFrame[playIndex].movYInc = (KeyFrame[playIndex + 1].movY - KeyFrame[playIndex].movY) / i_max_steps;
    KeyFrame[playIndex].movZInc = (KeyFrame[playIndex + 1].movZ - KeyFrame[playIndex].movZ) / i_max_steps;
    KeyFrame[playIndex].giroYInc = (KeyFrame[playIndex + 1].giroY - KeyFrame[playIndex].giroY) / i_max_steps;
    KeyFrame[playIndex].giroXInc = (KeyFrame[playIndex + 1].giroX - KeyFrame[playIndex].giroX) / i_max_steps;
    KeyFrame[playIndex].giroZInc = (KeyFrame[playIndex + 1].giroZ - KeyFrame[playIndex].giroZ) / i_max_steps;
}

void ComponenteAnimacion::animateKeyframes(void)
{
    //Movimiento del objeto con barra espaciadora
    if (play)
    {
        if (i_curr_steps >= i_max_steps) //fin de animaci�n entre frames?
        {
            playIndex++;
            printf("playindex : %d\n", playIndex);
            if (playIndex > FrameIndex - 2)	//Fin de toda la animaci�n con �ltimo frame?
            {
                printf("Frame index= %d\n", FrameIndex);
                printf("termino la animacion\n");
                playIndex = 0;
                play = false;
            }
            else //Interpolaci�n del pr�ximo cuadro
            {

                i_curr_steps = 0; //Resetea contador
                //Interpolar
                interpolation();
            }
        }
        else
        {
            //Dibujar Animaci�n
            entidad->posicionLocal.x += KeyFrame[playIndex].movXInc;
            entidad->posicionLocal.y += KeyFrame[playIndex].movYInc;
            entidad->posicionLocal.z += KeyFrame[playIndex].movZInc;
            entidad->rotacionLocal.x += KeyFrame[playIndex].giroXInc;
            entidad->rotacionLocal.y += KeyFrame[playIndex].giroYInc;
            entidad->rotacionLocal.z += KeyFrame[playIndex].giroZInc;
            entidad->actualizarTransformacion();
            i_curr_steps++;
        }

    }
}

